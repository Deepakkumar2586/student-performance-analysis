from pathlib import Path
import sys

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
from student_performance.analysis import association_summary, train_baseline
from student_performance.data import DataValidationError, load_data, quality_summary

st.set_page_config(page_title="Student Performance | Insights", page_icon="📚", layout="wide", initial_sidebar_state="expanded")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@500;600;700;800&display=swap');
html, body, [class*="css"] {font-family:'DM Sans',sans-serif}
h1,h2,h3 {font-family:'Manrope',sans-serif; letter-spacing:-.025em}
[data-testid="stMetric"] {background:#f4f7fb;border:1px solid #e5ebf2;padding:18px 20px;border-radius:14px}
.block-container {padding-top:2rem; padding-bottom:3rem; max-width:1450px}
</style>
""", unsafe_allow_html=True)

@st.cache_data(show_spinner=False)
def get_data():
    return load_data()

st.title("Student Performance Analysis")
st.caption("Explore academic outcomes across Mathematics and Portuguese subject records.")
try:
    raw = get_data()
except DataValidationError as exc:
    st.error(str(exc))
    st.stop()

with st.sidebar:
    st.header("Explore the data")
    subjects = st.multiselect("Subject", sorted(raw.subject.unique()), default=sorted(raw.subject.unique()))
    schools = st.multiselect("School", sorted(raw.school.unique()), default=sorted(raw.school.unique()))
    sex = st.multiselect("Sex", sorted(raw.sex.unique()), default=sorted(raw.sex.unique()))
    st.divider()
    st.caption("The included files contain separate subject records. Some students appear in both subjects, so the row count is enrollments, not unique people.")

filtered = raw[raw.subject.isin(subjects) & raw.school.isin(schools) & raw.sex.isin(sex)].copy()
if filtered.empty:
    st.info("Choose at least one subject, school, and sex to see results.")
    st.stop()

summary = quality_summary(filtered)
strong_rate = filtered["grade_band"].eq("Strong").mean()
mean_grade = filtered.G3.mean()
col1, col2, col3, col4 = st.columns(4)
col1.metric("Subject records", f"{len(filtered):,}")
col2.metric("Average final grade", f"{mean_grade:.1f} / 20")
col3.metric("Strong grade band", f"{strong_rate:.0%}")
col4.metric("Average absences", f"{filtered.absences.mean():.1f}")
st.caption("Grade bands: Needs support 0–9 · Developing 10–14 · Strong 15–20. These are descriptive groupings, not formal school classifications.")

tab_overview, tab_factors, tab_data, tab_model = st.tabs(["Overview", "Patterns & factors", "Data explorer", "Model demonstration"])
with tab_overview:
    left, right = st.columns([1.25, 1])
    with left:
        hist = px.histogram(filtered, x="G3", color="subject", barmode="overlay", opacity=.78, nbins=21,
                            color_discrete_sequence=["#3178c6", "#e88a54"], labels={"G3":"Final grade (0–20)","count":"Records"},
                            title="Final grade distribution")
        hist.update_layout(legend_title_text="Subject", margin=dict(l=10,r=10,t=55,b=10), height=360)
        st.plotly_chart(hist, use_container_width=True)
    with right:
        subject_means = filtered.groupby("subject", as_index=False)[["G1","G2","G3"]].mean().melt("subject", var_name="Period", value_name="Average grade")
        subject_means["Period"] = subject_means.Period.map({"G1":"Period 1", "G2":"Period 2", "G3":"Final"})
        line = px.line(subject_means, x="Period", y="Average grade", color="subject", markers=True,
                       color_discrete_sequence=["#3178c6", "#e88a54"], title="Average grades across the year")
        line.update_yaxes(range=[0,20]); line.update_layout(margin=dict(l=10,r=10,t=55,b=10), height=360, legend_title_text="Subject")
        st.plotly_chart(line, use_container_width=True)
    a,b = st.columns(2)
    with a:
        by_school = filtered.groupby("school", as_index=False).agg(records=("G3","size"), average=("G3","mean"))
        fig = px.bar(by_school, x="school", y="average", color="school", text=by_school.average.round(1),
                     labels={"school":"School code","average":"Average final grade"}, title="Average final grade by school")
        fig.update_yaxes(range=[0,20]); fig.update_layout(showlegend=False, height=330, margin=dict(t=55,b=10))
        st.plotly_chart(fig, use_container_width=True)
    with b:
        progression = px.scatter(filtered, x="G2", y="G3", color="subject", opacity=.65,
                                 labels={"G2":"Period 2 grade","G3":"Final grade"}, title="Period 2 and final grades")
        progression.update_layout(height=330, margin=dict(t=55,b=10), legend_title_text="Subject")
        st.plotly_chart(progression, use_container_width=True)

with tab_factors:
    st.markdown("### Compare grade-band rates")
    st.write("Choose a background factor to compare the share of subject records in each grade band. Differences are descriptive and do not establish cause.")
    choices = ["studytime","failures","schoolsup","famsup","higher","internet","romantic","address","goout","Walc","absences"]
    labels = {"studytime":"Weekly study time", "failures":"Past class failures", "schoolsup":"Extra school support", "famsup":"Family support", "higher":"Plans for higher education", "internet":"Internet access", "romantic":"Romantic relationship", "address":"Urban / rural", "goout":"Going out", "Walc":"Weekend alcohol use", "absences":"Absences"}
    factor = st.selectbox("Factor", choices, format_func=lambda x: labels[x])
    chart_data = association_summary(filtered, factor).reset_index().melt(id_vars=factor, var_name="Grade band", value_name="Share")
    chart_data[factor] = chart_data[factor].astype(str)
    fig = px.bar(chart_data, x=factor, y="Share", color="Grade band", barmode="stack", text=chart_data["Share"].map(lambda x: f"{x:.0%}"),
                 color_discrete_map={"Needs support":"#df765e", "Developing":"#e5b64b", "Strong":"#478b75"},
                 labels={factor:labels[factor],"Share":"Share of records"}, title=f"Grade bands by {labels[factor].lower()}")
    fig.update_layout(yaxis_tickformat=".0%", height=430, margin=dict(t=55,b=10), legend_title_text="Grade band")
    st.plotly_chart(fig, use_container_width=True)
    count = filtered.groupby(factor, dropna=False).size().rename("Records").reset_index()
    count[factor] = count[factor].astype(str)
    st.dataframe(count.rename(columns={factor:labels[factor]}), hide_index=True, use_container_width=True)
    st.markdown("### Numeric relationships")
    numeric = filtered[["age","studytime","failures","absences","G1","G2","G3","Dalc","Walc","goout"]].corr()
    heat = px.imshow(numeric, text_auto=".2f", color_continuous_scale="RdBu_r", zmin=-1,zmax=1, aspect="auto", title="Correlation matrix")
    heat.update_layout(height=560, margin=dict(t=55,b=10))
    st.plotly_chart(heat, use_container_width=True)
    st.caption("Correlations show pairwise association only. They do not account for confounding and should not be interpreted as causal effects.")

with tab_data:
    st.markdown("### Data quality and records")
    q1,q2,q3,q4 = st.columns(4)
    q1.metric("Missing cells", f"{summary['missing_cells']:,}")
    q2.metric("Exact duplicate profiles", f"{summary['duplicate_rows']:,}")
    q3.metric("Out-of-range grade rows", f"{summary['invalid_grades']:,}")
    q4.metric("Fields", f"{len(raw.columns)-2}")
    st.caption("Repeated profiles can represent the same student recorded in two different subjects. They are not removed because each is a valid subject enrollment.")
    view = filtered.copy()
    if not st.checkbox("Show student demographic and support fields", value=False):
        view = view[["subject","school","sex","age","studytime","failures","absences","G1","G2","G3","grade_band"]]
    st.dataframe(view, hide_index=True, use_container_width=True, height=420)
    st.download_button("Download filtered records (CSV)", view.to_csv(index=False).encode("utf-8"), "student-performance-filtered.csv", "text/csv")
    st.markdown("**Data source:** UCI Student Performance dataset (Mathematics and Portuguese, 2008–2009). See `docs/README.md` for attribution and field notes.")

with tab_model:
    st.markdown("### Reproducible baseline")
    st.write("A stratified 75/25 holdout split and a preprocessing pipeline demonstrate classification. Preprocessing is fit on training data only.")
    include_grades = st.checkbox("Include period 1 and period 2 grades (G1/G2)", value=False, help="Including earlier grades makes the task easier but changes the prediction question. They are excluded by default to avoid target-adjacent inputs.")
    st.warning("Do not use these predictions to make decisions about individual students. The public dataset is small, historical, and may not represent your school.")
    if st.button("Run baseline model", type="primary"):
        with st.spinner("Fitting the baseline and evaluating the holdout set…"):
            try:
                result = train_baseline(filtered, include_current_grades=include_grades)
                m1,m2,m3 = st.columns(3)
                m1.metric("Holdout accuracy", f"{result['accuracy']:.1%}")
                m2.metric("Balanced accuracy", f"{result['balanced_accuracy']:.1%}")
                m3.metric("Holdout records", f"{result['n_test']:,}")
                cm = px.imshow(result["matrix"], x=result["labels"], y=result["labels"], text_auto=True,
                               color_continuous_scale="Blues", labels=dict(x="Predicted", y="Actual", color="Records"), title="Confusion matrix")
                st.plotly_chart(cm, use_container_width=True)
                importance = pd.DataFrame({"Feature":result["feature_names"],"Importance":result["feature_importance"]}).sort_values("Importance", ascending=False).head(12)
                imp = px.bar(importance.sort_values("Importance"), x="Importance", y="Feature", orientation="h", title="Most informative encoded features")
                st.plotly_chart(imp, use_container_width=True)
                st.caption("A single holdout score has uncertainty. Use cross-validation and external validation before drawing conclusions.")
            except ValueError as exc:
                st.error(f"The selected filters leave too few examples per grade band to create a stratified split. Broaden the filters and try again. Details: {exc}")

st.divider()
st.caption("Student Performance Analysis · Educational exploration only · Built with Python, Streamlit, pandas, Plotly, and scikit-learn")

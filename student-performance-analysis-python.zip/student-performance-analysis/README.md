# Student Performance Analysis

A polished, interactive Python dashboard for exploring the UCI Student Performance dataset. It brings the original notebook's useful work into a maintainable app: grade distributions, progress across periods, factor comparisons, correlation analysis, data-quality checks, CSV export, and an optional leakage-aware classification demonstration.

## Quick start

Requires Python 3.10 or newer.

```bash
# 1. Create and activate an environment
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1

# 2. Install dependencies
python -m pip install -r requirements.txt

# 3. Start the dashboard
streamlit run app.py
```

Streamlit prints a local URL (usually http://localhost:8501). Keep `data/` beside `app.py`; the dashboard validates both CSVs at startup and gives a readable error if either is missing or malformed.

## Project structure

```text
student-performance-analysis/
├── app.py                         # Streamlit UI and interactive charts
├── src/student_performance/
│   ├── data.py                    # Loading, validation, quality summary
│   └── analysis.py                # Descriptive helpers and model pipeline
├── data/
│   ├── student-mat.csv            # Mathematics records
│   ├── student-por.csv            # Portuguese records
│   └── processed_set.csv          # Original merged reference file
├── docs/                          # Original proposal, report, and notebook
├── requirements.txt
└── README.md
```

## Dashboard guide

- **Overview:** filter by subject, school, and sex; inspect score distributions, progression, school averages, and G2/G3 relationships.
- **Patterns & factors:** compare grade-band shares across study time, prior failures, support, and other available factors. Review numerical correlations.
- **Data explorer:** inspect quality counts and records, reveal additional fields, and download the filtered table.
- **Model demonstration:** optionally run a deterministic Random Forest baseline using a stratified 75/25 holdout. G1 and G2 are excluded by default; enable them only when the question explicitly allows earlier period grades as inputs.

## Data and interpretation

The bundled files are the Mathematics and Portuguese subject tables from the UCI Student Performance dataset. Each row represents one subject enrollment. A student can appear in both files, so combining the files gives **1,044 subject records**, not 1,044 unique students. The app intentionally retains both records and does not deduplicate on row index or demographic profile.

G3 is the final grade on a 0–20 scale. The dashboard uses simple descriptive bands: **Needs support** (0–9), **Developing** (10–14), and **Strong** (15–20). These are convenient analytical groupings, not official labels. Correlation and factor comparisons are descriptive and do not establish cause. The demonstration model is not validated for student-level decisions; it uses a small historical dataset and should not be used to rank, label, or determine support for individual students.

The app checks required columns, reports missing and out-of-range values, and uses a fixed random seed for repeatable model splits. The scikit-learn pipeline fits imputers and encoders on training data only. The optional model result can vary across dependency versions.

## Attribution and references

The original project files are retained in `docs/`, including its report, proposal, comparison image, and notebook. The supplied processed CSV is retained as a reference but the app builds its records directly from the two subject CSVs so subject labels remain explicit.

Dataset: [UCI Machine Learning Repository — Student Performance](https://archive.ics.uci.edu/dataset/320/student+performance). Source research: P. Cortez and A. Silva, “Using Data Mining to Predict Secondary School Student Performance,” 2008.

## Troubleshooting

- **`streamlit: command not found`:** activate the virtual environment and install requirements again using `python -m pip install -r requirements.txt`.
- **Dataset missing:** restore `data/student-mat.csv` and `data/student-por.csv` from this project archive.
- **Model says there are too few examples:** broaden the sidebar selections so each grade band has enough records for a stratified split.
- **Port already in use:** run `streamlit run app.py --server.port 8502`.

## License and privacy

The source dataset is provided by UCI; consult its current repository terms before redistribution beyond this educational project. This app runs locally and does not upload student records. Avoid adding identifiable or sensitive data to a shared deployment.

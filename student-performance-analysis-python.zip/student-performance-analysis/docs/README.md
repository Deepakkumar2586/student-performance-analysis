# Source materials

This folder preserves the original project's proposal, report, comparison image, and exploratory notebook for reference. The supported application is the Streamlit dashboard at the project root. The notebook is retained as historical source material and is not required to run the app.

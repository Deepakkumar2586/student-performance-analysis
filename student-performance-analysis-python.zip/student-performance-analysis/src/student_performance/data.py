"""Dataset loading and validation for the UCI student performance records."""
from __future__ import annotations

from pathlib import Path
import pandas as pd

EXPECTED_COLUMNS = {
    "school", "sex", "age", "address", "famsize", "Pstatus", "Medu", "Fedu",
    "Mjob", "Fjob", "reason", "guardian", "traveltime", "studytime", "failures",
    "schoolsup", "famsup", "paid", "activities", "nursery", "higher", "internet",
    "romantic", "famrel", "freetime", "goout", "Dalc", "Walc", "health",
    "absences", "G1", "G2", "G3",
}
GRADE_COLUMNS = ["G1", "G2", "G3"]

class DataValidationError(ValueError):
    """Raised when a source CSV is missing or malformed."""


def load_data(data_dir: str | Path | None = None) -> pd.DataFrame:
    """Load subject records independently; a row represents one subject enrollment."""
    root = Path(data_dir) if data_dir else Path(__file__).resolve().parents[2] / "data"
    parts = []
    for filename, subject in (("student-mat.csv", "Mathematics"), ("student-por.csv", "Portuguese")):
        path = root / filename
        if not path.is_file():
            raise DataValidationError(f"Dataset not found: {path}. Restore the bundled data files.")
        try:
            frame = pd.read_csv(path, sep=";", encoding="utf-8")
        except (OSError, UnicodeError, pd.errors.ParserError) as exc:
            raise DataValidationError(f"Could not read {filename}: {exc}") from exc
        missing = EXPECTED_COLUMNS.difference(frame.columns)
        if missing:
            raise DataValidationError(f"{filename} is missing required columns: {', '.join(sorted(missing))}")
        frame = frame.copy()
        frame["subject"] = subject
        frame["grade_band"] = pd.cut(frame["G3"], bins=[-1, 9, 14, 20], labels=["Needs support", "Developing", "Strong"])
        parts.append(frame)
    data = pd.concat(parts, ignore_index=True)
    for col in GRADE_COLUMNS + ["age", "absences"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    return data


def quality_summary(data: pd.DataFrame) -> dict[str, int | float]:
    return {
        "records": len(data),
        "missing_cells": int(data.isna().sum().sum()),
        "duplicate_rows": int(data.duplicated(subset=[c for c in data.columns if c != "subject"]).sum()),
        "invalid_grades": int((~data[GRADE_COLUMNS].apply(lambda s: s.between(0, 20)).all(axis=1)).sum()),
    }

"""Reusable descriptive analysis and leakage-aware classification helpers."""
from __future__ import annotations
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier


def grade_summary(data: pd.DataFrame) -> pd.DataFrame:
    return data.groupby("subject", observed=True)[["G1", "G2", "G3", "absences"]].agg(["mean", "median", "std"]).round(2)


def association_summary(data: pd.DataFrame, factor: str) -> pd.DataFrame:
    """Grade-band rates within each factor category; denominators remain visible."""
    return (pd.crosstab(data[factor], data["grade_band"], normalize="index")
            .reindex(columns=["Needs support", "Developing", "Strong"], fill_value=0))


def train_baseline(data: pd.DataFrame, include_current_grades: bool = False) -> dict:
    """Evaluate a stratified holdout model; test data is never used to fit transforms."""
    features = [c for c in data.columns if c not in {"G3", "grade_band"}]
    if not include_current_grades:
        features = [c for c in features if c not in {"G1", "G2"}]
    X = data[features].copy()
    y = data["grade_band"].astype(str)
    categorical = list(X.select_dtypes(include=["object", "category"]).columns)
    numeric = [c for c in X.columns if c not in categorical]
    prep = ColumnTransformer([
        ("numeric", Pipeline([("impute", SimpleImputer(strategy="median")), ("scale", StandardScaler())]), numeric),
        ("categorical", Pipeline([("impute", SimpleImputer(strategy="most_frequent")), ("encode", OneHotEncoder(handle_unknown="ignore"))]), categorical),
    ])
    model = Pipeline([("prepare", prep), ("classifier", RandomForestClassifier(n_estimators=300, min_samples_leaf=3, class_weight="balanced", random_state=42, n_jobs=-1))])
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.25, random_state=42, stratify=y)
    model.fit(X_train, y_train)
    predicted = model.predict(X_test)
    labels = ["Needs support", "Developing", "Strong"]
    return {
        "accuracy": accuracy_score(y_test, predicted),
        "balanced_accuracy": balanced_accuracy_score(y_test, predicted),
        "matrix": confusion_matrix(y_test, predicted, labels=labels),
        "report": classification_report(y_test, predicted, labels=labels, output_dict=True, zero_division=0),
        "labels": labels,
        "feature_importance": model.named_steps["classifier"].feature_importances_,
        "feature_names": model.named_steps["prepare"].get_feature_names_out(),
        "n_train": len(X_train), "n_test": len(X_test),
        "warning": "This demonstration model is not validated for student-level decisions. It describes associations and must not be used to label or rank individual students.",
    }
